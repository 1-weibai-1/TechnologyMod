
package net.wei_bai.technology.client.gui;

import net.wei_bai.technology.world.inventory.Primitiveworks1GUIMenu;
import net.wei_bai.technology.procedures.Waterprogressbar9Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar8Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar7Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar6Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar5Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar4Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar40Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar3Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar39Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar38Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar37Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar36Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar35Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar34Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar33Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar32Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar31Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar30Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar2Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar29Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar28Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar27Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar26Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar25Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar24Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar23Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar22Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar21Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar20Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar1Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar19Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar18Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar17Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar16Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar15Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar14Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar13Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar12Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar11Procedure;
import net.wei_bai.technology.procedures.Waterprogressbar10Procedure;
import net.wei_bai.technology.procedures.Waterdropprogressbar9Procedure;
import net.wei_bai.technology.procedures.Waterdropprogressbar8Procedure;
import net.wei_bai.technology.procedures.Waterdropprogressbar7Procedure;
import net.wei_bai.technology.procedures.Waterdropprogressbar6Procedure;
import net.wei_bai.technology.procedures.Waterdropprogressbar5Procedure;
import net.wei_bai.technology.procedures.Waterdropprogressbar4Procedure;
import net.wei_bai.technology.procedures.Waterdropprogressbar3Procedure;
import net.wei_bai.technology.procedures.Waterdropprogressbar2Procedure;
import net.wei_bai.technology.procedures.Waterdropprogressbar1Procedure;
import net.wei_bai.technology.procedures.Waterdropprogressbar16Procedure;
import net.wei_bai.technology.procedures.Waterdropprogressbar15Procedure;
import net.wei_bai.technology.procedures.Waterdropprogressbar14Procedure;
import net.wei_bai.technology.procedures.Waterdropprogressbar13Procedure;
import net.wei_bai.technology.procedures.Waterdropprogressbar12Procedure;
import net.wei_bai.technology.procedures.Waterdropprogressbar11Procedure;
import net.wei_bai.technology.procedures.Waterdropprogressbar10Procedure;
import net.wei_bai.technology.procedures.Arrowprogressbar9Procedure;
import net.wei_bai.technology.procedures.Arrowprogressbar8Procedure;
import net.wei_bai.technology.procedures.Arrowprogressbar7Procedure;
import net.wei_bai.technology.procedures.Arrowprogressbar6Procedure;
import net.wei_bai.technology.procedures.Arrowprogressbar5Procedure;
import net.wei_bai.technology.procedures.Arrowprogressbar4Procedure;
import net.wei_bai.technology.procedures.Arrowprogressbar3Procedure;
import net.wei_bai.technology.procedures.Arrowprogressbar2Procedure;
import net.wei_bai.technology.procedures.Arrowprogressbar1Procedure;
import net.wei_bai.technology.procedures.Arrowprogressbar16Procedure;
import net.wei_bai.technology.procedures.Arrowprogressbar15Procedure;
import net.wei_bai.technology.procedures.Arrowprogressbar14Procedure;
import net.wei_bai.technology.procedures.Arrowprogressbar13Procedure;
import net.wei_bai.technology.procedures.Arrowprogressbar12Procedure;
import net.wei_bai.technology.procedures.Arrowprogressbar11Procedure;
import net.wei_bai.technology.procedures.Arrowprogressbar10Procedure;
import net.wei_bai.technology.network.Primitiveworks1GUIButtonMessage;
import net.wei_bai.technology.TechnologyMod;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.Minecraft;

import java.util.HashMap;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.systems.RenderSystem;

public class Primitiveworks1GUIScreen extends AbstractContainerScreen<Primitiveworks1GUIMenu> {
	private final static HashMap<String, Object> guistate = Primitiveworks1GUIMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;

	public Primitiveworks1GUIScreen(Primitiveworks1GUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 226;
		this.imageHeight = 194;
	}

	private static final ResourceLocation texture = new ResourceLocation("technology:textures/screens/primitiveworks_1_gui.png");

	@Override
	public void render(PoseStack ms, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(ms);
		super.render(ms, mouseX, mouseY, partialTicks);
		this.renderTooltip(ms, mouseX, mouseY);
	}

	@Override
	protected void renderBg(PoseStack ms, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShaderTexture(0, texture);
		this.blit(ms, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/knife_stone.png"));
		this.blit(ms, this.leftPos + 120, this.topPos + 14, 0, 0, 42, 42, 42, 42);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 4, this.topPos + 19, 0, 0, 19, 19, 19, 19);

		if (Waterprogressbar1Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_01.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar2Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_02.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar3Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_03.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar4Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_04.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar5Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_05.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar6Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_06.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar7Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_07.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar8Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_08.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar9Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_09.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar10Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_10.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar11Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_11.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar12Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_12.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar13Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_13.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar14Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_14.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar15Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_15.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar16Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_16.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar17Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_17.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar18Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_18.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar19Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_19.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar20Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_20.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar21Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_21.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar22Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_22.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar23Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_23.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar24Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_24.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar25Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_25.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar26Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_26.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar27Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_27.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar28Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_28.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar29Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_29.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar30Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_30.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar31Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_31.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar32Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_32.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar33Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_33.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar34Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_34.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar35Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_35.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar36Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_36.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar37Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_37.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar38Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_38.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar39Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_39.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}
		if (Waterprogressbar40Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_40.png"));
			this.blit(ms, this.leftPos + 31, this.topPos + 21, 0, 0, 12, 82, 12, 82);
		}

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_storage_frame.png"));
		this.blit(ms, this.leftPos + 29, this.topPos + 19, 0, 0, 16, 86, 16, 86);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_00.png"));
		this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);

		if (Waterdropprogressbar1Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_01.png"));
			this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);
		}
		if (Waterdropprogressbar2Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_02.png"));
			this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);
		}
		if (Waterdropprogressbar3Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_03.png"));
			this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);
		}
		if (Waterdropprogressbar4Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_04.png"));
			this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);
		}
		if (Waterdropprogressbar5Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_05.png"));
			this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);
		}
		if (Waterdropprogressbar6Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_06.png"));
			this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);
		}
		if (Waterdropprogressbar7Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_07.png"));
			this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);
		}
		if (Waterdropprogressbar8Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_08.png"));
			this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);
		}
		if (Waterdropprogressbar9Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_09.png"));
			this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);
		}
		if (Waterdropprogressbar10Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_10.png"));
			this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);
		}
		if (Waterdropprogressbar11Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_11.png"));
			this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);
		}
		if (Waterdropprogressbar12Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_12.png"));
			this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);
		}
		if (Waterdropprogressbar13Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_13.png"));
			this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);
		}
		if (Waterdropprogressbar14Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_14.png"));
			this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);
		}
		if (Waterdropprogressbar15Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_15.png"));
			this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);
		}
		if (Waterdropprogressbar16Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/water_drop_16.png"));
			this.blit(ms, this.leftPos + 4, this.topPos + 48, 0, 0, 19, 32, 19, 32);
		}

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/bucket_frame.png"));
		this.blit(ms, this.leftPos + 4, this.topPos + 19, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_0.png"));
		this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);

		if (Arrowprogressbar1Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_1.png"));
			this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);
		}
		if (Arrowprogressbar2Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_2.png"));
			this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);
		}
		if (Arrowprogressbar3Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_3.png"));
			this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);
		}
		if (Arrowprogressbar4Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_4.png"));
			this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);
		}
		if (Arrowprogressbar5Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_5.png"));
			this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);
		}
		if (Arrowprogressbar6Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_6.png"));
			this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);
		}
		if (Arrowprogressbar7Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_7.png"));
			this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);
		}
		if (Arrowprogressbar8Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_8.png"));
			this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);
		}
		if (Arrowprogressbar9Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_9.png"));
			this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);
		}
		if (Arrowprogressbar10Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_10.png"));
			this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);
		}
		if (Arrowprogressbar11Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_11.png"));
			this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);
		}
		if (Arrowprogressbar12Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_12.png"));
			this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);
		}
		if (Arrowprogressbar13Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_13.png"));
			this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);
		}
		if (Arrowprogressbar14Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_14.png"));
			this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);
		}

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 175, this.topPos + 94, 0, 0, 19, 19, 19, 19);

		if (Arrowprogressbar15Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_15.png"));
			this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);
		}
		if (Arrowprogressbar16Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/arrow_16.png"));
			this.blit(ms, this.leftPos + 122, this.topPos + 51, 0, 0, 38, 21, 38, 21);
		}

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 157, this.topPos + 94, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 139, this.topPos + 94, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/a_pinch_of_slag.png"));
		this.blit(ms, this.leftPos + 140, this.topPos + 95, 0, 0, 16, 16, 16, 16);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/powder.png"));
		this.blit(ms, this.leftPos + 158, this.topPos + 95, 0, 0, 16, 16, 16, 16);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/stone_slag.png"));
		this.blit(ms, this.leftPos + 175, this.topPos + 94, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 92, this.topPos + 70, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 4, this.topPos + 87, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 92, this.topPos + 52, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 74, this.topPos + 70, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 56, this.topPos + 70, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 56, this.topPos + 34, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 74, this.topPos + 52, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 74, this.topPos + 34, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 56, this.topPos + 52, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 92, this.topPos + 34, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 175, this.topPos + 52, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 175, this.topPos + 112, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 157, this.topPos + 112, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 139, this.topPos + 112, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 121, this.topPos + 112, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 31, this.topPos + 112, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 49, this.topPos + 112, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 67, this.topPos + 112, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 85, this.topPos + 112, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 103, this.topPos + 112, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 31, this.topPos + 130, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 49, this.topPos + 130, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 67, this.topPos + 130, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 85, this.topPos + 130, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 103, this.topPos + 130, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 31, this.topPos + 148, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 49, this.topPos + 148, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 67, this.topPos + 148, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 85, this.topPos + 148, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 103, this.topPos + 148, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 121, this.topPos + 130, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 121, this.topPos + 148, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 139, this.topPos + 130, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 139, this.topPos + 148, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 157, this.topPos + 130, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 175, this.topPos + 130, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 157, this.topPos + 148, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 175, this.topPos + 148, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 31, this.topPos + 170, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 49, this.topPos + 170, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 67, this.topPos + 170, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 103, this.topPos + 170, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 85, this.topPos + 170, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 121, this.topPos + 170, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 139, this.topPos + 170, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 157, this.topPos + 170, 0, 0, 19, 19, 19, 19);

		RenderSystem.setShaderTexture(0, new ResourceLocation("technology:textures/screens/lattice_0.png"));
		this.blit(ms, this.leftPos + 175, this.topPos + 170, 0, 0, 19, 19, 19, 19);

		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	public void containerTick() {
		super.containerTick();
	}

	@Override
	protected void renderLabels(PoseStack poseStack, int mouseX, int mouseY) {
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "tick")) + "", 163, 29, -12829636);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "tick_max")) + "", 162, 40, -12829636);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "Water_progress_bar")) + "", 20, 5, -12829636);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "true")) + "", 199, 75, -12829636);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "item_true")) + "", 70, 89, -12829636);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_2_id")) + "", -94, 3, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_3_id")) + "", -76, 3, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_4_id")) + "", -58, 3, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_5_id")) + "", -94, 21, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_6_id")) + "", -76, 21, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_7_id")) + "", -58, 21, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_8_id")) + "", -94, 39, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_9_id")) + "", -76, 39, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_10_id")) + "", -58, 39, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_2_level")) + "", -94, 93, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_3_level")) + "", -76, 93, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_4_level")) + "", -58, 93, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_5_level")) + "", -94, 111, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_6_level")) + "", -76, 111, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_7_level")) + "", -58, 111, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_8_level")) + "", -94, 129, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_9_level")) + "", -76, 129, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "slot_10_level")) + "", -58, 129, -256);
		this.font.draw(poseStack, "" + (new Object() {
			public double getValue(BlockPos pos, String tag) {
				BlockEntity BlockEntity = world.getBlockEntity(pos);
				if (BlockEntity != null)
					return BlockEntity.getTileData().getDouble(tag);
				return 0;
			}
		}.getValue(new BlockPos((int) x, (int) y, (int) z), "time%")) + "", 70, 17, -12829636);
	}

	@Override
	public void onClose() {
		super.onClose();
		Minecraft.getInstance().keyboardHandler.setSendRepeatsToGui(false);
	}

	@Override
	public void init() {
		super.init();
		this.minecraft.keyboardHandler.setSendRepeatsToGui(true);
		this.addRenderableWidget(new Button(this.leftPos + 162, this.topPos + 72, 35, 20, new TextComponent("确定"), e -> {
			if (true) {
				TechnologyMod.PACKET_HANDLER.sendToServer(new Primitiveworks1GUIButtonMessage(0, x, y, z));
				Primitiveworks1GUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}));
	}
}
